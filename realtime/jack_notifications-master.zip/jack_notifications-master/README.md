Jack Notifications V1.1 - 27/11/14
==================

Sistema de notificaciones en tiempo real con PHP y nodejs

Instrucciones
==================
1.-Crear base de datos "jack_notifications" (o la que tu usar�s)

2.-Configurar archivos con accesos y llave secreta (jacknotifications.php, jack_notifications_srv.js)

3.-Instalar socket.io y mysql para nodejs
	npm install socket.io
	npm install mysql

4.-Ejecutar servidor NodeJS (jack_notifications_srv.js)

5.-Ver el demo (index.html) en diferentes navegadores.
